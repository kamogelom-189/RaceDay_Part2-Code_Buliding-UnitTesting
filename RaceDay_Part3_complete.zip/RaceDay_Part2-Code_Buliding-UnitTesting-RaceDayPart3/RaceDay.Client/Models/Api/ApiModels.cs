namespace RaceDay.Client.Models.Api
{
    // These classes only describe the JSON the API sends back.
    // They contain no database or business logic.

    public class LoginResponse
    {
        public string Token { get; set; } = string.Empty;
        public int UserId { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public DateTime ExpiresAt { get; set; }
    }

    public class EventDto
    {
        public int EventId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string? Description { get; set; }
        public DateTime EventDate { get; set; }
        public string Location { get; set; } = string.Empty;
        public decimal DistanceKM { get; set; }
        public string EventType { get; set; } = "run";
        public int OrganiserId { get; set; }
        public bool HasBanner { get; set; }
    }

    // GET api/events/mine (organiser dashboard)
    public class OrganiserEventDto : EventDto
    {
        public int CategoryCount { get; set; }
        public int EnrolmentCount { get; set; }
        public int ConfirmedCount { get; set; }
        public int PendingCount { get; set; }
    }

    public class CategoryDto
    {
        public int CategoryId { get; set; }
        public int EventId { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public decimal DistanceKM { get; set; }
        public decimal EntryFee { get; set; }
    }

    // GET api/enrolments/my (a participant's own enrolments)
    public class MyEnrolmentDto
    {
        public int EnrolmentId { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public int EventId { get; set; }
        public string EventName { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
        public string EventLocation { get; set; } = string.Empty;
        public DateTime EnrolmentDate { get; set; }
        public string PaymentStatus { get; set; } = "Pending";
    }

    // GET api/events/{id}/enrolments (organiser view)
    public class EventEnrolmentDto
    {
        public int EnrolmentId { get; set; }
        public int ParticipantId { get; set; }
        public string ParticipantName { get; set; } = string.Empty;
        public string ParticipantEmail { get; set; } = string.Empty;
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public DateTime EnrolmentDate { get; set; }
        public string PaymentStatus { get; set; } = "Pending";
    }

    // GET api/events/{id}/results (organiser view)
    public class EventResultDto
    {
        public int ResultId { get; set; }
        public int EnrolmentId { get; set; }
        public string RaceNumber { get; set; } = string.Empty;
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public int ParticipantId { get; set; }
        public string ParticipantName { get; set; } = string.Empty;
        public string CategoryName { get; set; } = string.Empty;
    }

    // GET api/results/my (participant's race history)
    public class MyResultDto
    {
        public int ResultId { get; set; }
        public string RaceNumber { get; set; } = string.Empty;
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public int TotalFinishers { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public int EventId { get; set; }
        public string EventName { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
    }

    public class ProfileDto
    {
        public int UserId { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public bool HasPicture { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
