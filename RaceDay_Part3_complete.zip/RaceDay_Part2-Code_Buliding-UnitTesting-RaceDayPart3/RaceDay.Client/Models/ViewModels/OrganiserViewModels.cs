using System.ComponentModel.DataAnnotations;
using RaceDay.Client.Models.Api;

namespace RaceDay.Client.Models.ViewModels
{
    public class OrganiserDashboardViewModel
    {
        public string FullName { get; set; } = string.Empty;
        public int TotalEvents { get; set; }
        public int UpcomingEvents { get; set; }
        public int TotalEnrolments { get; set; }
        public int ConfirmedEnrolments { get; set; }
        public int PendingEnrolments { get; set; }
        public List<OrganiserEventDto> Events { get; set; } = new();
    }

    // Used by both "Create event" and "Edit event".
    public class EventFormViewModel
    {
        public int EventId { get; set; }

        [Required(ErrorMessage = "Please enter an event name.")]
        [StringLength(150, ErrorMessage = "The name must be 150 characters or fewer.")]
        [Display(Name = "Event name")]
        public string Title { get; set; } = string.Empty;

        [StringLength(2000, ErrorMessage = "The description must be 2000 characters or fewer.")]
        public string? Description { get; set; }

        [Required(ErrorMessage = "Please choose the event date and time.")]
        [Display(Name = "Date and time")]
        public DateTime? EventDate { get; set; }

        [Required(ErrorMessage = "Please enter the location.")]
        [StringLength(150, ErrorMessage = "The location must be 150 characters or fewer.")]
        public string Location { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter the distance in kilometres.")]
        [Range(0.01, 9999.99, ErrorMessage = "Distance must be between 0.01 and 9999.99 km.")]
        [Display(Name = "Distance (km)")]
        public decimal? DistanceKM { get; set; }

        [Required(ErrorMessage = "Please choose an event type.")]
        [RegularExpression("^(run|walk|cycle)$",
            ErrorMessage = "Event type must be run, walk or cycle.")]
        [Display(Name = "Event type")]
        public string EventType { get; set; } = "run";

        [Display(Name = "Banner image")]
        public IFormFile? Banner { get; set; }

        // Shown on the edit page so the organiser sees the current banner.
        public bool HasBanner { get; set; }
    }

    public class CategoryFormViewModel
    {
        public int CategoryId { get; set; }

        public int EventId { get; set; }

        [Required(ErrorMessage = "Please enter a category name.")]
        [StringLength(100, ErrorMessage = "The name must be 100 characters or fewer.")]
        [Display(Name = "Category name")]
        public string CategoryName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter the distance in kilometres.")]
        [Range(0.01, 999.99, ErrorMessage = "Distance must be between 0.01 and 999.99 km.")]
        [Display(Name = "Distance (km)")]
        public decimal? DistanceKM { get; set; }

        [Required(ErrorMessage = "Please enter the entry fee (use 0 for free).")]
        [Range(0, 1000000, ErrorMessage = "Entry fee must be 0 or more.")]
        [Display(Name = "Entry fee (R)")]
        public decimal? EntryFee { get; set; }
    }

    public class CategoriesPageViewModel
    {
        public EventDto Event { get; set; } = new();
        public List<CategoryDto> Categories { get; set; } = new();
        public CategoryFormViewModel NewCategory { get; set; } = new();
    }

    public class EnrolmentsPageViewModel
    {
        public EventDto Event { get; set; } = new();
        public List<EventEnrolmentDto> Enrolments { get; set; } = new();
    }

    public class ResultsPageViewModel
    {
        public EventDto Event { get; set; } = new();

        // Results can only be captured once the event has taken place.
        public bool EventHasPassed { get; set; }

        public List<EventResultDto> Results { get; set; } = new();

        // Enrolments that do not have a result yet.
        public List<EventEnrolmentDto> AwaitingResults { get; set; } = new();
    }

    public class ResultFormViewModel
    {
        public int EventId { get; set; }

        public int EnrolmentId { get; set; }

        [Required(ErrorMessage = "Please enter the race number.")]
        [StringLength(20, ErrorMessage = "The race number must be 20 characters or fewer.")]
        [Display(Name = "Race number")]
        public string RaceNumber { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter the finish time as hh:mm:ss.")]
        [Display(Name = "Finish time")]
        public string FinishTime { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter the finishing position.")]
        [Range(1, 1000000, ErrorMessage = "Position must be 1 or more.")]
        public int? Position { get; set; }
    }
}
