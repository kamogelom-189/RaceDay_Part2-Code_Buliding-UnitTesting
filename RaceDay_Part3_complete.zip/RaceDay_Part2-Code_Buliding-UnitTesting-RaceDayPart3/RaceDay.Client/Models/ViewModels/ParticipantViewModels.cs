using System.ComponentModel.DataAnnotations;
using RaceDay.Client.Models.Api;

namespace RaceDay.Client.Models.ViewModels
{
    public class ParticipantDashboardViewModel
    {
        public string FullName { get; set; } = string.Empty;
        public int UpcomingEnrolments { get; set; }
        public int PendingEnrolments { get; set; }
        public int RacesCompleted { get; set; }
        public int? BestPosition { get; set; }
        public MyEnrolmentDto? NextRace { get; set; }
        public List<EventDto> SuggestedEvents { get; set; } = new();
    }

    public class EventFilterViewModel
    {
        public string? Search { get; set; }

        public string? Type { get; set; }

        [Range(0, 9999.99)]
        public decimal? MaxDistance { get; set; }

        public DateTime? FromDate { get; set; }

        public bool IncludePast { get; set; }
    }

    public class EventsIndexViewModel
    {
        public EventFilterViewModel Filter { get; set; } = new();
        public List<EventDto> Events { get; set; } = new();
        public int TotalBeforeFilter { get; set; }
    }

    public class EventDetailsViewModel
    {
        public EventDto Event { get; set; } = new();
        public List<CategoryDto> Categories { get; set; } = new();

        // Categories this participant has already enrolled in.
        public HashSet<int> EnrolledCategoryIds { get; set; } = new();

        public bool EventHasPassed { get; set; }
    }

    public class ProfileViewModel
    {
        public ProfileDto Profile { get; set; } = new();

        public ProfileFormViewModel Form { get; set; } = new();
    }

    public class ProfileFormViewModel
    {
        [Required(ErrorMessage = "Please enter your full name.")]
        [StringLength(100, ErrorMessage = "Your name must be 100 characters or fewer.")]
        [Display(Name = "Full name")]
        public string FullName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter your email address.")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address.")]
        [StringLength(150, ErrorMessage = "Your email must be 150 characters or fewer.")]
        [Display(Name = "Email address")]
        public string Email { get; set; } = string.Empty;
    }
}
