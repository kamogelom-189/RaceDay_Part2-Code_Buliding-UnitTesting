using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using RaceDay.Client.Services;

namespace RaceDay.Client.Filters
{
    // Protects a controller or action using the session.
    //   [SessionAuthorize]               any signed-in user
    //   [SessionAuthorize("Organiser")]  only that role
    // Hiding a menu link is not security; this filter is.
    [AttributeUsage(
        AttributeTargets.Class | AttributeTargets.Method,
        AllowMultiple = true)]
    public class SessionAuthorizeAttribute : Attribute, IAuthorizationFilter
    {
        private readonly string? _role;

        public SessionAuthorizeAttribute()
        {
        }

        public SessionAuthorizeAttribute(string role)
        {
            _role = role;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var http = context.HttpContext;
            var session = http.Session;

            if (!session.IsLoggedIn())
            {
                bool hadToken = !string.IsNullOrWhiteSpace(
                    session.GetString(SessionKeys.Token));

                session.Clear();

                string? returnUrl =
                    HttpMethods.IsGet(http.Request.Method)
                        ? $"{http.Request.Path}{http.Request.QueryString}"
                        : null;

                context.Result = new RedirectToActionResult(
                    "Login",
                    "Account",
                    new
                    {
                        returnUrl,
                        reason = hadToken ? "expired" : "required"
                    });

                return;
            }

            if (_role != null &&
                !string.Equals(
                    session.GetRole(), _role,
                    StringComparison.OrdinalIgnoreCase))
            {
                context.Result = new RedirectToActionResult(
                    "AccessDenied", "Account", null);
            }
        }
    }
}
