using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using System.Globalization;
using RaceDay.Client.Services;

var builder = WebApplication.CreateBuilder(args);

// 1. MVC (controllers and views). Every POST is protected
//    against cross-site request forgery.
builder.Services.AddControllersWithViews(options =>
{
    options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
});

// 2. Session: remembers the signed-in user's token and role.
builder.Services.AddHttpContextAccessor();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.Name = ".RaceDay.Session";
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// 3. HttpClient: the ONLY way this application gets or saves data.
builder.Services.AddHttpClient("Api", client =>
{
    string baseUrl = builder.Configuration["ApiSettings:BaseUrl"]
        ?? throw new InvalidOperationException(
            "ApiSettings:BaseUrl is missing from appsettings.json.");

    // BaseAddress must end with "/" so relative URLs combine correctly.
    client.BaseAddress = new Uri(baseUrl.TrimEnd('/') + "/");
    client.Timeout = TimeSpan.FromSeconds(30);
});

builder.Services.AddScoped<ApiService>();

var app = builder.Build();

// Friendly error pages: users never see a raw exception.
app.UseExceptionHandler("/Home/Error");
app.UseStatusCodePagesWithReExecute("/Home/HandleStatus", "?code={0}");

if (!app.Environment.IsDevelopment())
{
    app.UseHsts();
}

// Inside Docker the container only listens on plain HTTP (port 8080),
// so HTTPS redirection is skipped there.
if (!string.Equals(
        Environment.GetEnvironmentVariable("DOTNET_RUNNING_IN_CONTAINER"),
        "true",
        StringComparison.OrdinalIgnoreCase))
{
    app.UseHttpsRedirection();
}

app.UseStaticFiles();

// Use the invariant culture so numbers (5.5) and dates (2026-12-01)
// are read the same way on every computer and inside Docker.
var supportedCultures = new[] { CultureInfo.InvariantCulture };
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture(CultureInfo.InvariantCulture),
    SupportedCultures = supportedCultures,
    SupportedUICultures = supportedCultures
});

app.UseRouting();

app.UseSession();        // must come after UseRouting
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
