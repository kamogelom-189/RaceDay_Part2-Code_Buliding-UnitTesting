using System.Globalization;

namespace RaceDay.Client.Helpers
{
    // Small formatting helpers shared by every page so that dates,
    // times and status colours look the same everywhere.
    public static class DisplayHelpers
    {
        private static readonly CultureInfo Invariant =
            CultureInfo.InvariantCulture;

        public static string FormatDate(DateTime date) =>
            date.ToString("ddd, dd MMM yyyy", Invariant);

        public static string FormatDateTime(DateTime date) =>
            date.ToString("ddd, dd MMM yyyy 'at' HH:mm", Invariant);

        public static string FormatShortDate(DateTime date) =>
            date.ToString("dd MMM yyyy", Invariant);

        public static string FormatFinishTime(TimeSpan? time) =>
            time.HasValue
                ? time.Value.ToString(@"hh\:mm\:ss", Invariant)
                : "-";

        public static string FormatDistance(decimal km) =>
            km.ToString("0.##", Invariant) + " km";

        public static string FormatMoney(decimal amount) =>
            "R " + amount.ToString("N2", Invariant);

        public static string EventTypeLabel(string type) =>
            string.IsNullOrWhiteSpace(type)
                ? "Event"
                : char.ToUpperInvariant(type[0]) + type[1..].ToLowerInvariant();

        // 1 -> 1st, 2 -> 2nd, 11 -> 11th, 47 -> 47th ...
        public static string Ordinal(int number)
        {
            int lastTwo = number % 100;

            if (lastTwo >= 11 && lastTwo <= 13)
            {
                return number + "th";
            }

            return (number % 10) switch
            {
                1 => number + "st",
                2 => number + "nd",
                3 => number + "rd",
                _ => number + "th"
            };
        }

        // "47th of 312 finishers"
        public static string PositionText(int? position, int totalFinishers)
        {
            if (!position.HasValue)
            {
                return "-";
            }

            string ordinal = Ordinal(position.Value);

            if (totalFinishers <= 0)
            {
                return ordinal;
            }

            string noun = totalFinishers == 1 ? "finisher" : "finishers";

            return $"{ordinal} of {totalFinishers} {noun}";
        }

        // The database stores "Paid"; the website calls it "Confirmed".
        public static string StatusLabel(string? status) =>
            (status ?? string.Empty).Trim().ToLowerInvariant() switch
            {
                "paid" or "confirmed" => "Confirmed",
                "pending" => "Pending",
                "cancelled" => "Cancelled",
                _ => string.IsNullOrWhiteSpace(status) ? "Unknown" : status
            };

        // green = Confirmed, amber = Pending, red = Cancelled
        public static string StatusCss(string? status) =>
            (status ?? string.Empty).Trim().ToLowerInvariant() switch
            {
                "paid" or "confirmed" => "status-confirmed",
                "pending" => "status-pending",
                "cancelled" => "status-cancelled",
                _ => "status-unknown"
            };

        public static string Initials(string? fullName)
        {
            if (string.IsNullOrWhiteSpace(fullName))
            {
                return "?";
            }

            var parts = fullName.Split(
                ' ', StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length == 1)
            {
                return parts[0][..1].ToUpperInvariant();
            }

            return (parts[0][..1] + parts[^1][..1]).ToUpperInvariant();
        }
    }
}
