using System.Net;

namespace RaceDay.Client.Services
{
    // The outcome of one call to the API. Controllers check Success
    // and show Error (always a friendly message) when it is false.
    public class ApiResult
    {
        public bool Success { get; init; }

        public HttpStatusCode? StatusCode { get; init; }

        public string Error { get; init; } = string.Empty;

        public bool IsUnauthorized =>
            StatusCode == HttpStatusCode.Unauthorized;

        public bool IsForbidden =>
            StatusCode == HttpStatusCode.Forbidden;

        public bool IsNotFound =>
            StatusCode == HttpStatusCode.NotFound;

        public bool IsConflict =>
            StatusCode == HttpStatusCode.Conflict;
    }

    public class ApiResult<T> : ApiResult
    {
        public T? Data { get; init; }
    }

    // A file (image) returned by the API.
    public record FileData(byte[] Bytes, string ContentType);
}
