using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDay.Client.Services
{
    // Every request from the MVC application to the RaceDay API goes
    // through this class. It attaches the signed-in user's JWT from
    // session and turns every failure into a friendly message.
    public class ApiService
    {
        private const string UnreachableMessage =
            "We could not reach the RaceDay service. " +
            "Please try again in a moment.";

        private static readonly JsonSerializerOptions JsonOptions =
            new(JsonSerializerDefaults.Web);

        private readonly IHttpClientFactory _clientFactory;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILogger<ApiService> _logger;

        public ApiService(
            IHttpClientFactory clientFactory,
            IHttpContextAccessor httpContextAccessor,
            ILogger<ApiService> logger)
        {
            _clientFactory = clientFactory;
            _httpContextAccessor = httpContextAccessor;
            _logger = logger;
        }

        public Task<ApiResult<T>> GetAsync<T>(string url) =>
            SendAsync<T>(HttpMethod.Get, url, null);

        public Task<ApiResult<T>> PostAsync<T>(string url, object? body) =>
            SendAsync<T>(HttpMethod.Post, url, ToJson(body));

        public Task<ApiResult<object>> PostAsync(string url, object? body) =>
            SendAsync<object>(HttpMethod.Post, url, ToJson(body));

        public Task<ApiResult<object>> PutAsync(string url, object? body) =>
            SendAsync<object>(HttpMethod.Put, url, ToJson(body));

        public Task<ApiResult<object>> DeleteAsync(string url) =>
            SendAsync<object>(HttpMethod.Delete, url, null);

        // Sends an image to the API as multipart/form-data.
        // The API (not MVC) stores it in Azure Blob Storage.
        public async Task<ApiResult<object>> PostFileAsync(
            string url, IFormFile file)
        {
            await using var stream = file.OpenReadStream();
            using var form = new MultipartFormDataContent();

            var fileContent = new StreamContent(stream);

            if (MediaTypeHeaderValue.TryParse(
                    file.ContentType, out var mediaType))
            {
                fileContent.Headers.ContentType = mediaType;
            }

            form.Add(fileContent, "file", file.FileName);

            return await SendAsync<object>(HttpMethod.Post, url, form);
        }

        // Downloads an image streamed by the API.
        public async Task<ApiResult<FileData>> GetFileAsync(string url)
        {
            try
            {
                using var client = CreateClient();
                using var response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return new ApiResult<FileData>
                    {
                        Success = false,
                        StatusCode = response.StatusCode,
                        Error = await ReadErrorAsync(response)
                    };
                }

                byte[] bytes = await response.Content.ReadAsByteArrayAsync();

                string contentType =
                    response.Content.Headers.ContentType?.MediaType
                    ?? "application/octet-stream";

                return new ApiResult<FileData>
                {
                    Success = true,
                    StatusCode = response.StatusCode,
                    Data = new FileData(bytes, contentType)
                };
            }
            catch (Exception ex) when (IsNetworkProblem(ex))
            {
                _logger.LogWarning(ex, "API file request failed: {Url}", url);

                return new ApiResult<FileData>
                {
                    Success = false,
                    Error = UnreachableMessage
                };
            }
        }

        private async Task<ApiResult<T>> SendAsync<T>(
            HttpMethod method, string url, HttpContent? content)
        {
            try
            {
                using var client = CreateClient();
                using var request = new HttpRequestMessage(method, url)
                {
                    Content = content
                };
                using var response = await client.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    return new ApiResult<T>
                    {
                        Success = false,
                        StatusCode = response.StatusCode,
                        Error = await ReadErrorAsync(response)
                    };
                }

                T? data = default;

                if (typeof(T) != typeof(object) &&
                    response.Content.Headers.ContentLength != 0)
                {
                    data = await response.Content
                        .ReadFromJsonAsync<T>(JsonOptions);
                }

                return new ApiResult<T>
                {
                    Success = true,
                    StatusCode = response.StatusCode,
                    Data = data
                };
            }
            catch (Exception ex) when (IsNetworkProblem(ex))
            {
                _logger.LogWarning(
                    ex, "API request failed: {Method} {Url}", method, url);

                return new ApiResult<T>
                {
                    Success = false,
                    Error = UnreachableMessage
                };
            }
        }

        private HttpClient CreateClient()
        {
            var client = _clientFactory.CreateClient("Api");

            string? token = _httpContextAccessor.HttpContext?
                .Session.GetString(SessionKeys.Token);

            if (!string.IsNullOrWhiteSpace(token))
            {
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }

            return client;
        }

        private static HttpContent? ToJson(object? body)
        {
            if (body == null)
            {
                return null;
            }

            return JsonContent.Create(
                body, body.GetType(), null, JsonOptions);
        }

        private static bool IsNetworkProblem(Exception ex) =>
            ex is HttpRequestException
            || ex is TaskCanceledException
            || ex is JsonException
            || ex is NotSupportedException;

        // Turns an error response into a message safe to show users.
        private static async Task<string> ReadErrorAsync(
            HttpResponseMessage response)
        {
            string fallback = response.StatusCode switch
            {
                HttpStatusCode.Unauthorized =>
                    "Your session has expired. Please sign in again.",
                HttpStatusCode.Forbidden =>
                    "You do not have permission to do that.",
                HttpStatusCode.NotFound =>
                    "We could not find what you were looking for.",
                HttpStatusCode.Conflict =>
                    "That conflicts with information we already have.",
                HttpStatusCode.BadRequest =>
                    "Some of the information entered is not valid.",
                _ =>
                    "Something went wrong on our side. " +
                    "Please try again in a moment."
            };

            try
            {
                string body = await response.Content.ReadAsStringAsync();

                if (string.IsNullOrWhiteSpace(body))
                {
                    return fallback;
                }

                using var document = JsonDocument.Parse(body);
                var root = document.RootElement;

                if (root.ValueKind != JsonValueKind.Object)
                {
                    return fallback;
                }

                // { "message": "..." } from our own API code.
                if (root.TryGetProperty("message", out var message) &&
                    message.ValueKind == JsonValueKind.String)
                {
                    string? text = message.GetString();

                    if (!string.IsNullOrWhiteSpace(text))
                    {
                        return text;
                    }
                }

                // Automatic validation errors: { "errors": { "Field": [..] } }
                if (root.TryGetProperty("errors", out var errors) &&
                    errors.ValueKind == JsonValueKind.Object)
                {
                    var messages = new List<string>();

                    foreach (var field in errors.EnumerateObject())
                    {
                        if (field.Value.ValueKind != JsonValueKind.Array)
                        {
                            continue;
                        }

                        foreach (var item in field.Value.EnumerateArray())
                        {
                            string? text = item.GetString();

                            if (!string.IsNullOrWhiteSpace(text))
                            {
                                messages.Add(text);
                            }
                        }
                    }

                    if (messages.Count > 0)
                    {
                        return string.Join(" ", messages.Distinct());
                    }
                }
            }
            catch (JsonException)
            {
                // Not JSON: use the safe fallback message.
            }

            return fallback;
        }
    }
}
