using System.Globalization;
using RaceDay.Client.Models.Api;

namespace RaceDay.Client.Services
{
    public static class SessionKeys
    {
        public const string Token = "Token";
        public const string Role = "Role";
        public const string FullName = "FullName";
        public const string Email = "Email";
        public const string UserId = "UserId";
        public const string ExpiresAt = "ExpiresAt";
    }

    public static class RaceDaySessionExtensions
    {
        // Saves everything we need about the signed-in user.
        public static void SignIn(this ISession session, LoginResponse login)
        {
            session.SetString(SessionKeys.Token, login.Token);
            session.SetString(SessionKeys.Role, login.Role);
            session.SetString(SessionKeys.FullName, login.FullName);
            session.SetString(SessionKeys.Email, login.Email);
            session.SetString(
                SessionKeys.UserId,
                login.UserId.ToString(CultureInfo.InvariantCulture));
            session.SetString(
                SessionKeys.ExpiresAt,
                login.ExpiresAt.ToUniversalTime()
                    .ToString("O", CultureInfo.InvariantCulture));
        }

        // True only when a token exists AND it has not expired.
        public static bool IsLoggedIn(this ISession session)
        {
            string? token = session.GetString(SessionKeys.Token);

            if (string.IsNullOrWhiteSpace(token))
            {
                return false;
            }

            string? expires = session.GetString(SessionKeys.ExpiresAt);

            if (DateTime.TryParse(
                    expires,
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.RoundtripKind,
                    out DateTime expiresAt) &&
                expiresAt <= DateTime.UtcNow)
            {
                return false;
            }

            return true;
        }

        public static string GetRole(this ISession session) =>
            session.GetString(SessionKeys.Role) ?? string.Empty;

        public static string GetFullName(this ISession session) =>
            session.GetString(SessionKeys.FullName) ?? string.Empty;

        public static int? GetUserId(this ISession session)
        {
            if (int.TryParse(
                    session.GetString(SessionKeys.UserId),
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out int id))
            {
                return id;
            }

            return null;
        }
    }
}
