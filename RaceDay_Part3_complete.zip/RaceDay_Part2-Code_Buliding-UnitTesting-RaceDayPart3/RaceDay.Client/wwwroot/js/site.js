// RaceDay: small helpers used across pages.

// Ask before submitting any form marked with data-confirm="...".
document.addEventListener('submit', function (event) {
    var form = event.target;
    var message = form.getAttribute('data-confirm');

    if (message && !window.confirm(message)) {
        event.preventDefault();
    }
});

// Disable submit buttons after the first click so a slow API
// response cannot cause a double submission.
document.addEventListener('submit', function (event) {
    if (event.defaultPrevented) {
        return;
    }

    var buttons = event.target.querySelectorAll('button[type="submit"][data-busy-text]');

    buttons.forEach(function (button) {
        button.disabled = true;
        button.textContent = button.getAttribute('data-busy-text');
    });
});

// Show a live preview of an image chosen in a file input
// marked with data-preview="#imgElementId".
document.addEventListener('change', function (event) {
    var input = event.target;
    var selector = input.getAttribute && input.getAttribute('data-preview');

    if (!selector || !input.files || input.files.length === 0) {
        return;
    }

    var preview = document.querySelector(selector);

    if (preview) {
        preview.src = URL.createObjectURL(input.files[0]);
        preview.classList.remove('d-none');
    }
});
