using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Filters;
using RaceDay.Client.Models.Api;
using RaceDay.Client.Models.ViewModels;

namespace RaceDay.Client.Controllers
{
    [SessionAuthorize("Participant")]
    public class EventsController : BaseController
    {
        // Participant home: upcoming events with filtering options.
        [HttpGet]
        public async Task<IActionResult> Index(EventFilterViewModel filter)
        {
            var result = await Api.GetAsync<List<EventDto>>("api/Events");

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!result.Success)
            {
                ShowError(result.Error);
            }

            var all = result.Data ?? new List<EventDto>();
            IEnumerable<EventDto> events = all;

            // By default only upcoming events are shown.
            if (!filter.IncludePast)
            {
                events = events.Where(e => e.EventDate >= DateTime.Now);
            }

            if (!string.IsNullOrWhiteSpace(filter.Search))
            {
                string term = filter.Search.Trim();

                events = events.Where(e =>
                    e.Title.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                    e.Location.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                    (e.Description ?? string.Empty).Contains(
                        term, StringComparison.OrdinalIgnoreCase));
            }

            if (!string.IsNullOrWhiteSpace(filter.Type))
            {
                events = events.Where(e => string.Equals(
                    e.EventType, filter.Type,
                    StringComparison.OrdinalIgnoreCase));
            }

            if (filter.MaxDistance.HasValue && filter.MaxDistance.Value > 0)
            {
                events = events.Where(e => e.DistanceKM <= filter.MaxDistance.Value);
            }

            if (filter.FromDate.HasValue)
            {
                events = events.Where(e => e.EventDate.Date >= filter.FromDate.Value.Date);
            }

            return View(new EventsIndexViewModel
            {
                Filter = filter,
                TotalBeforeFilter = all.Count,
                Events = events.OrderBy(e => e.EventDate).ToList()
            });
        }

        // Full event information and the available categories.
        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var eventResult = await Api.GetAsync<EventDto>($"api/Events/{id}");

            if (eventResult.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!eventResult.Success || eventResult.Data == null)
            {
                ShowError(eventResult.IsNotFound
                    ? "That event could not be found."
                    : eventResult.Error);

                return RedirectToAction(nameof(Index));
            }

            var categories = await Api.GetAsync<List<CategoryDto>>(
                $"api/events/{id}/categories");

            var mine = await Api.GetAsync<List<MyEnrolmentDto>>(
                "api/enrolments/my");

            if (!categories.Success)
            {
                ShowError(categories.Error);
            }

            var enrolledIds = (mine.Data ?? new List<MyEnrolmentDto>())
                .Where(e => !string.Equals(e.PaymentStatus, "Cancelled",
                    StringComparison.OrdinalIgnoreCase))
                .Select(e => e.CategoryId)
                .ToHashSet();

            return View(new EventDetailsViewModel
            {
                Event = eventResult.Data,
                Categories = (categories.Data ?? new List<CategoryDto>())
                    .OrderBy(c => c.DistanceKM)
                    .ToList(),
                EnrolledCategoryIds = enrolledIds,
                EventHasPassed = eventResult.Data.EventDate < DateTime.Now
            });
        }

        // Enrol in the chosen category. The API records it as Pending.
        [HttpPost]
        public async Task<IActionResult> Enrol(int id, int? categoryId)
        {
            if (!categoryId.HasValue)
            {
                ShowError("Please choose a category before enrolling.");
                return RedirectToAction(nameof(Details), new { id });
            }

            var result = await Api.PostAsync(
                $"api/events/{id}/enrolments",
                new { categoryId = categoryId.Value });

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!result.Success)
            {
                ShowError(result.Error);
                return RedirectToAction(nameof(Details), new { id });
            }

            ShowSuccess(
                "You are enrolled! Your enrolment is pending until the " +
                "organiser confirms it.");

            return RedirectToAction("Index", "MyEnrolments");
        }
    }
}
