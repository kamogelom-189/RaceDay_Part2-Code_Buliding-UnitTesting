using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Filters;
using RaceDay.Client.Models.Api;

namespace RaceDay.Client.Controllers
{
    [SessionAuthorize("Participant")]
    public class MyResultsController : BaseController
    {
        // The participant's personal race history.
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var result = await Api.GetAsync<List<MyResultDto>>(
                "api/results/my");

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!result.Success)
            {
                ShowError(result.Error);
            }

            return View((result.Data ?? new List<MyResultDto>())
                .OrderByDescending(r => r.EventDate)
                .ToList());
        }
    }
}
