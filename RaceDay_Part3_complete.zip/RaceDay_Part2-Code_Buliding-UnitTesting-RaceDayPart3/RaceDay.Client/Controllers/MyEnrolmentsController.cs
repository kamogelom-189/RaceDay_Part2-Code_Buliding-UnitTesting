using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Filters;
using RaceDay.Client.Models.Api;

namespace RaceDay.Client.Controllers
{
    [SessionAuthorize("Participant")]
    public class MyEnrolmentsController : BaseController
    {
        // Every event the participant has enrolled for, with its status.
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var result = await Api.GetAsync<List<MyEnrolmentDto>>(
                "api/enrolments/my");

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!result.Success)
            {
                ShowError(result.Error);
            }

            return View((result.Data ?? new List<MyEnrolmentDto>())
                .OrderByDescending(e => e.EventDate)
                .ToList());
        }
    }
}
