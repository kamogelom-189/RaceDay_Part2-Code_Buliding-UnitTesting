using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Filters;
using RaceDay.Client.Models.Api;
using RaceDay.Client.Models.ViewModels;
using RaceDay.Client.Services;

namespace RaceDay.Client.Controllers
{
    // Both roles can view and update their own profile.
    [SessionAuthorize]
    public class ProfileController : BaseController
    {
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var model = await LoadAsync();

            if (model == null)
            {
                return SessionExpired();
            }

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Update(ProfileFormViewModel form)
        {
            if (!ModelState.IsValid)
            {
                var invalid = await LoadAsync();

                if (invalid == null)
                {
                    return SessionExpired();
                }

                invalid.Form = form;
                return View("Index", invalid);
            }

            var result = await Api.PutAsync("api/Profile/me", new
            {
                fullName = form.FullName.Trim(),
                email = form.Email.Trim()
            });

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!result.Success)
            {
                var failed = await LoadAsync();

                if (failed == null)
                {
                    return SessionExpired();
                }

                failed.Form = form;
                ModelState.AddModelError(string.Empty, result.Error);
                return View("Index", failed);
            }

            // Keep the name shown in the menu up to date.
            HttpContext.Session.SetString(
                SessionKeys.FullName, form.FullName.Trim());

            ShowSuccess("Your profile was updated.");

            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> UploadPicture(IFormFile? picture)
        {
            if (picture == null || picture.Length == 0)
            {
                ShowError("Please choose an image to upload.");
                return RedirectToAction(nameof(Index));
            }

            string? imageError = ValidateImage(picture);

            if (imageError != null)
            {
                ShowError(imageError);
                return RedirectToAction(nameof(Index));
            }

            var result = await Api.PostFileAsync(
                "api/Profile/me/picture", picture);

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (result.Success)
            {
                ShowSuccess("Your profile picture was updated.");
            }
            else
            {
                ShowError(result.Error);
            }

            return RedirectToAction(nameof(Index));
        }

        // Returns null when the session has expired.
        private async Task<ProfileViewModel?> LoadAsync()
        {
            var result = await Api.GetAsync<ProfileDto>("api/Profile/me");

            if (result.IsUnauthorized)
            {
                return null;
            }

            if (!result.Success || result.Data == null)
            {
                ShowError(result.Error);

                // Fall back to what we know from the session.
                return new ProfileViewModel
                {
                    Profile = new ProfileDto
                    {
                        FullName = HttpContext.Session.GetFullName(),
                        Email = HttpContext.Session.GetString(SessionKeys.Email) ?? string.Empty,
                        Role = HttpContext.Session.GetRole()
                    },
                    Form = new ProfileFormViewModel
                    {
                        FullName = HttpContext.Session.GetFullName(),
                        Email = HttpContext.Session.GetString(SessionKeys.Email) ?? string.Empty
                    }
                };
            }

            return new ProfileViewModel
            {
                Profile = result.Data,
                Form = new ProfileFormViewModel
                {
                    FullName = result.Data.FullName,
                    Email = result.Data.Email
                }
            };
        }
    }
}
