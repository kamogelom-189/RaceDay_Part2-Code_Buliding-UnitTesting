using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Models.Api;
using RaceDay.Client.Services;

namespace RaceDay.Client.Controllers
{
    // Shared helpers for every controller that talks to the API.
    // NoStore stops the browser showing protected pages from its
    // cache after the user has signed out (Back button).
    [ResponseCache(
        Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public abstract class BaseController : Controller
    {
        private const long MaxImageBytes = 2 * 1024 * 1024;

        private static readonly string[] AllowedImageTypes =
            { "image/jpeg", "image/png", "image/webp" };

        private ApiService? _api;

        protected ApiService Api =>
            _api ??= HttpContext.RequestServices
                .GetRequiredService<ApiService>();

        protected int CurrentUserId =>
            HttpContext.Session.GetUserId() ?? 0;

        protected void ShowSuccess(string message) =>
            TempData["Success"] = message;

        protected void ShowError(string message) =>
            TempData["Error"] = message;

        // The API said our token is no longer valid.
        protected IActionResult SessionExpired()
        {
            HttpContext.Session.Clear();

            return RedirectToAction(
                "Login", "Account", new { reason = "expired" });
        }

        // Same rules as the API, checked first for a friendlier message.
        protected static string? ValidateImage(IFormFile? file)
        {
            if (file == null || file.Length == 0)
            {
                return null; // no file chosen is allowed
            }

            if (file.Length > MaxImageBytes)
            {
                return "The image must be 2 MB or smaller.";
            }

            if (!AllowedImageTypes.Contains(file.ContentType.ToLowerInvariant()))
            {
                return "Only JPEG, PNG or WebP images are allowed.";
            }

            return null;
        }

        // The first validation message on the form, for pages that
        // show one alert instead of per-field messages.
        protected string FirstModelError()
        {
            var message = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .FirstOrDefault(m => !string.IsNullOrWhiteSpace(m));

            return message ?? "Please check the information you entered.";
        }

        // Loads an event and makes sure the signed-in organiser owns it.
        protected async Task<(EventDto? Event, IActionResult? Redirect)>
            LoadOwnedEventAsync(int eventId)
        {
            var result = await Api.GetAsync<EventDto>($"api/Events/{eventId}");

            if (result.IsUnauthorized)
            {
                return (null, SessionExpired());
            }

            if (!result.Success || result.Data == null)
            {
                ShowError(result.IsNotFound
                    ? "That event could not be found."
                    : result.Error);

                return (null, RedirectToAction("Index", "OrganiserEvents"));
            }

            if (result.Data.OrganiserId != CurrentUserId)
            {
                ShowError("You can only manage events that you created.");

                return (null, RedirectToAction("Index", "OrganiserEvents"));
            }

            return (result.Data, null);
        }
    }
}
