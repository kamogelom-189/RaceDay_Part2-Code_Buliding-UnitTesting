using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Models.Api;
using RaceDay.Client.Models.ViewModels;
using RaceDay.Client.Services;

namespace RaceDay.Client.Controllers
{
    public class AccountController : BaseController
    {
        [HttpGet]
        public IActionResult Login(string? returnUrl = null, string? reason = null)
        {
            if (HttpContext.Session.IsLoggedIn())
            {
                return RedirectToAction("Index", "Dashboard");
            }

            ViewData["Notice"] = reason switch
            {
                "expired" => "Your session has expired. Please sign in again.",
                "required" => "Please sign in to continue.",
                _ => null
            };

            return View(new LoginViewModel { ReturnUrl = returnUrl });
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var result = await Api.PostAsync<LoginResponse>(
                "api/Auth/login",
                new { email = model.Email.Trim(), password = model.Password });

            if (!result.Success || result.Data == null)
            {
                ModelState.AddModelError(string.Empty, result.Error);
                return View(model);
            }

            HttpContext.Session.SignIn(result.Data);

            ShowSuccess($"Welcome back, {result.Data.FullName}!");

            if (!string.IsNullOrWhiteSpace(model.ReturnUrl) &&
                Url.IsLocalUrl(model.ReturnUrl))
            {
                return LocalRedirect(model.ReturnUrl);
            }

            return RedirectToAction("Index", "Dashboard");
        }

        [HttpGet]
        public IActionResult Register()
        {
            if (HttpContext.Session.IsLoggedIn())
            {
                return RedirectToAction("Index", "Dashboard");
            }

            return View(new RegisterViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var result = await Api.PostAsync("api/Auth/register", new
            {
                fullName = model.FullName.Trim(),
                email = model.Email.Trim(),
                password = model.Password,
                roleName = model.RoleName
            });

            if (!result.Success)
            {
                ModelState.AddModelError(
                    result.IsConflict ? nameof(model.Email) : string.Empty,
                    result.Error);

                return View(model);
            }

            ShowSuccess("Your account has been created. You can now sign in.");

            return RedirectToAction(nameof(Login));
        }

        // POST so a link on another website cannot sign the user out.
        [HttpPost]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            ShowSuccess("You have been signed out.");

            return RedirectToAction(nameof(Login));
        }

        [HttpGet]
        public IActionResult AccessDenied()
        {
            Response.StatusCode = StatusCodes.Status403Forbidden;
            return View();
        }
    }
}
