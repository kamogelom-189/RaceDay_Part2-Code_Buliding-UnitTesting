using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Filters;
using RaceDay.Client.Models.Api;
using RaceDay.Client.Models.ViewModels;
using RaceDay.Client.Services;

namespace RaceDay.Client.Controllers
{
    public class DashboardController : BaseController
    {
        // Sends each role to its own dashboard.
        [SessionAuthorize]
        public IActionResult Index()
        {
            bool isOrganiser = string.Equals(
                HttpContext.Session.GetRole(), "Organiser",
                StringComparison.OrdinalIgnoreCase);

            return isOrganiser
                ? RedirectToAction(nameof(Organiser))
                : RedirectToAction(nameof(Participant));
        }

        [SessionAuthorize("Organiser")]
        public async Task<IActionResult> Organiser()
        {
            var result = await Api.GetAsync<List<OrganiserEventDto>>(
                "api/Events/mine");

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!result.Success)
            {
                ShowError(result.Error);
            }

            var events = result.Data ?? new List<OrganiserEventDto>();

            var model = new OrganiserDashboardViewModel
            {
                FullName = HttpContext.Session.GetFullName(),
                TotalEvents = events.Count,
                UpcomingEvents = events.Count(e => e.EventDate >= DateTime.Now),
                TotalEnrolments = events.Sum(e => e.EnrolmentCount),
                ConfirmedEnrolments = events.Sum(e => e.ConfirmedCount),
                PendingEnrolments = events.Sum(e => e.PendingCount),
                Events = events.OrderBy(e => e.EventDate).ToList()
            };

            return View(model);
        }

        [SessionAuthorize("Participant")]
        public async Task<IActionResult> Participant()
        {
            var enrolments = await Api.GetAsync<List<MyEnrolmentDto>>(
                "api/enrolments/my");

            if (enrolments.IsUnauthorized)
            {
                return SessionExpired();
            }

            var results = await Api.GetAsync<List<MyResultDto>>(
                "api/results/my");

            var events = await Api.GetAsync<List<EventDto>>("api/Events");

            if (!enrolments.Success)
            {
                ShowError(enrolments.Error);
            }

            var myEnrolments = enrolments.Data ?? new List<MyEnrolmentDto>();
            var myResults = results.Data ?? new List<MyResultDto>();
            var allEvents = events.Data ?? new List<EventDto>();

            var activeUpcoming = myEnrolments
                .Where(e => e.EventDate >= DateTime.Now &&
                            !IsCancelled(e.PaymentStatus))
                .OrderBy(e => e.EventDate)
                .ToList();

            var enrolledEventIds = myEnrolments
                .Select(e => e.EventId)
                .ToHashSet();

            var model = new ParticipantDashboardViewModel
            {
                FullName = HttpContext.Session.GetFullName(),
                UpcomingEnrolments = activeUpcoming.Count,
                PendingEnrolments = activeUpcoming.Count(e =>
                    string.Equals(e.PaymentStatus, "Pending",
                        StringComparison.OrdinalIgnoreCase)),
                RacesCompleted = myResults.Count,
                BestPosition = myResults
                    .Where(r => r.Position.HasValue)
                    .Select(r => r.Position)
                    .OrderBy(p => p)
                    .FirstOrDefault(),
                NextRace = activeUpcoming.FirstOrDefault(),
                SuggestedEvents = allEvents
                    .Where(e => e.EventDate >= DateTime.Now &&
                                !enrolledEventIds.Contains(e.EventId))
                    .OrderBy(e => e.EventDate)
                    .Take(3)
                    .ToList()
            };

            return View(model);
        }

        private static bool IsCancelled(string status) =>
            string.Equals(status, "Cancelled",
                StringComparison.OrdinalIgnoreCase);
    }
}
