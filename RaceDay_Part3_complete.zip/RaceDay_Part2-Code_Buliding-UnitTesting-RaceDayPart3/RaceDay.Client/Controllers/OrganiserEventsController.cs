using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Filters;
using RaceDay.Client.Models.Api;
using RaceDay.Client.Models.ViewModels;

namespace RaceDay.Client.Controllers
{
    [SessionAuthorize("Organiser")]
    public class OrganiserEventsController : BaseController
    {
        // List of the organiser's events with their counts.
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var result = await Api.GetAsync<List<OrganiserEventDto>>(
                "api/Events/mine");

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!result.Success)
            {
                ShowError(result.Error);
            }

            return View(result.Data ?? new List<OrganiserEventDto>());
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View(new EventFormViewModel
            {
                EventDate = DateTime.Now.AddDays(30).Date.AddHours(8)
            });
        }

        [HttpPost]
        public async Task<IActionResult> Create(EventFormViewModel model)
        {
            string? imageError = ValidateImage(model.Banner);

            if (imageError != null)
            {
                ModelState.AddModelError(nameof(model.Banner), imageError);
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var created = await Api.PostAsync<EventDto>(
                "api/Events", ToPayload(model));

            if (created.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!created.Success || created.Data == null)
            {
                ModelState.AddModelError(string.Empty, created.Error);
                return View(model);
            }

            if (model.Banner != null && model.Banner.Length > 0)
            {
                var upload = await Api.PostFileAsync(
                    $"api/Events/{created.Data.EventId}/banner",
                    model.Banner);

                if (!upload.Success)
                {
                    ShowError(
                        "The event was created, but the banner could not " +
                        $"be uploaded. {upload.Error}");

                    return RedirectToAction(
                        nameof(Edit), new { id = created.Data.EventId });
                }
            }

            ShowSuccess($"\"{created.Data.Title}\" was created.");

            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var (raceEvent, redirect) = await LoadOwnedEventAsync(id);

            if (redirect != null || raceEvent == null)
            {
                return redirect ?? RedirectToAction(nameof(Index));
            }

            return View(ToForm(raceEvent));
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, EventFormViewModel model)
        {
            model.EventId = id;

            string? imageError = ValidateImage(model.Banner);

            if (imageError != null)
            {
                ModelState.AddModelError(nameof(model.Banner), imageError);
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var updated = await Api.PutAsync(
                $"api/Events/{id}", ToPayload(model));

            if (updated.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!updated.Success)
            {
                ModelState.AddModelError(string.Empty, updated.Error);
                return View(model);
            }

            if (model.Banner != null && model.Banner.Length > 0)
            {
                var upload = await Api.PostFileAsync(
                    $"api/Events/{id}/banner", model.Banner);

                if (!upload.Success)
                {
                    ShowError(
                        "The event was saved, but the banner could not " +
                        $"be uploaded. {upload.Error}");

                    return RedirectToAction(nameof(Edit), new { id });
                }
            }

            ShowSuccess("The event was updated.");

            return RedirectToAction(nameof(Index));
        }

        // Asks the organiser to confirm before anything is deleted.
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var (raceEvent, redirect) = await LoadOwnedEventAsync(id);

            if (redirect != null || raceEvent == null)
            {
                return redirect ?? RedirectToAction(nameof(Index));
            }

            return View(raceEvent);
        }

        [HttpPost]
        [ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var result = await Api.DeleteAsync($"api/Events/{id}");

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!result.Success)
            {
                ShowError(result.Error);
                return RedirectToAction(nameof(Index));
            }

            ShowSuccess("The event was deleted.");

            return RedirectToAction(nameof(Index));
        }

        // What the API expects when creating or updating an event.
        private static object ToPayload(EventFormViewModel model) => new
        {
            title = model.Title.Trim(),
            description = string.IsNullOrWhiteSpace(model.Description)
                ? null
                : model.Description.Trim(),
            eventDate = model.EventDate,
            location = model.Location.Trim(),
            distanceKM = model.DistanceKM,
            eventType = model.EventType
        };

        private static EventFormViewModel ToForm(EventDto raceEvent) => new()
        {
            EventId = raceEvent.EventId,
            Title = raceEvent.Title,
            Description = raceEvent.Description,
            EventDate = raceEvent.EventDate,
            Location = raceEvent.Location,
            DistanceKM = raceEvent.DistanceKM,
            EventType = raceEvent.EventType,
            HasBanner = raceEvent.HasBanner
        };
    }
}
