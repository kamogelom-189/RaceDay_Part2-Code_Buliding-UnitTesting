using System.Globalization;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Filters;
using RaceDay.Client.Models.Api;
using RaceDay.Client.Models.ViewModels;

namespace RaceDay.Client.Controllers
{
    [SessionAuthorize("Organiser")]
    public class OrganiserResultsController : BaseController
    {
        // hh:mm:ss, for example 01:23:45
        private static readonly Regex TimePattern =
            new(@"^\d{1,2}:[0-5]\d:[0-5]\d$", RegexOptions.Compiled);

        // Results entry page for ONE event.
        [HttpGet]
        public async Task<IActionResult> Index(int eventId)
        {
            var (raceEvent, redirect) = await LoadOwnedEventAsync(eventId);

            if (redirect != null || raceEvent == null)
            {
                return redirect ?? RedirectToAction("Index", "OrganiserEvents");
            }

            var enrolments = await Api.GetAsync<List<EventEnrolmentDto>>(
                $"api/events/{eventId}/enrolments");

            if (enrolments.IsUnauthorized)
            {
                return SessionExpired();
            }

            var results = await Api.GetAsync<List<EventResultDto>>(
                $"api/events/{eventId}/results");

            if (!enrolments.Success)
            {
                ShowError(enrolments.Error);
            }
            else if (!results.Success)
            {
                ShowError(results.Error);
            }

            var allResults = results.Data ?? new List<EventResultDto>();
            var withResult = allResults.Select(r => r.EnrolmentId).ToHashSet();

            var awaiting = (enrolments.Data ?? new List<EventEnrolmentDto>())
                .Where(e => !withResult.Contains(e.EnrolmentId) &&
                            !string.Equals(e.PaymentStatus, "Cancelled",
                                StringComparison.OrdinalIgnoreCase))
                .OrderBy(e => e.ParticipantName)
                .ToList();

            return View(new ResultsPageViewModel
            {
                Event = raceEvent,
                EventHasPassed = raceEvent.EventDate <= DateTime.Now,
                Results = allResults
                    .OrderBy(r => r.Position ?? int.MaxValue)
                    .ToList(),
                AwaitingResults = awaiting
            });
        }

        [HttpPost]
        public async Task<IActionResult> Add(
            int eventId, ResultFormViewModel model)
        {
            var (raceEvent, redirect) = await LoadOwnedEventAsync(eventId);

            if (redirect != null || raceEvent == null)
            {
                return redirect ?? RedirectToAction("Index", "OrganiserEvents");
            }

            if (raceEvent.EventDate > DateTime.Now)
            {
                ShowError("Results can only be captured after the event has taken place.");
                return RedirectToAction(nameof(Index), new { eventId });
            }

            string finishText = (model.FinishTime ?? string.Empty).Trim();

            if (!TimePattern.IsMatch(finishText) ||
                !TimeSpan.TryParse(
                    finishText, CultureInfo.InvariantCulture,
                    out TimeSpan finishTime) ||
                finishTime <= TimeSpan.Zero)
            {
                ModelState.AddModelError(
                    nameof(model.FinishTime),
                    "Enter the finish time as hours:minutes:seconds, for example 01:23:45.");
            }

            if (!ModelState.IsValid)
            {
                ShowError(FirstModelError());
                return RedirectToAction(nameof(Index), new { eventId });
            }

            var result = await Api.PostAsync("api/events/" + eventId + "/results", new
            {
                enrolmentId = model.EnrolmentId,
                raceNumber = model.RaceNumber.Trim(),
                finishTime = TimeSpan.Parse(finishText, CultureInfo.InvariantCulture)
                    .ToString("c", CultureInfo.InvariantCulture),
                position = model.Position
            });

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (result.Success)
            {
                ShowSuccess("The result was recorded and published.");
            }
            else
            {
                ShowError(result.Error);
            }

            return RedirectToAction(nameof(Index), new { eventId });
        }
    }
}
