using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Filters;

namespace RaceDay.Client.Controllers
{
    // MVC never talks to Azure. These actions ask the API for the
    // image (the API reads it from Blob Storage) and pass the bytes
    // on to the browser.
    [SessionAuthorize]
    public class ImagesController : BaseController
    {
        [HttpGet]
        public async Task<IActionResult> EventBanner(int id)
        {
            var result = await Api.GetFileAsync($"api/Events/{id}/banner");

            if (!result.Success || result.Data == null)
            {
                return NotFound();
            }

            return File(result.Data.Bytes, result.Data.ContentType);
        }

        [HttpGet]
        public async Task<IActionResult> ProfilePicture()
        {
            var result = await Api.GetFileAsync("api/Profile/me/picture");

            if (!result.Success || result.Data == null)
            {
                return NotFound();
            }

            return File(result.Data.Bytes, result.Data.ContentType);
        }
    }
}
