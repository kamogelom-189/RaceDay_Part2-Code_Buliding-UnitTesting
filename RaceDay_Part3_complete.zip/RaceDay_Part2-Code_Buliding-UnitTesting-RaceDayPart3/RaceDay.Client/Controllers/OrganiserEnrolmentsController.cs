using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Filters;
using RaceDay.Client.Models.Api;
using RaceDay.Client.Models.ViewModels;

namespace RaceDay.Client.Controllers
{
    [SessionAuthorize("Organiser")]
    public class OrganiserEnrolmentsController : BaseController
    {
        // Everyone who enrolled in ONE event, with category and status.
        [HttpGet]
        public async Task<IActionResult> Index(int eventId)
        {
            var (raceEvent, redirect) = await LoadOwnedEventAsync(eventId);

            if (redirect != null || raceEvent == null)
            {
                return redirect ?? RedirectToAction("Index", "OrganiserEvents");
            }

            var result = await Api.GetAsync<List<EventEnrolmentDto>>(
                $"api/events/{eventId}/enrolments");

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!result.Success)
            {
                ShowError(result.Error);
            }

            return View(new EnrolmentsPageViewModel
            {
                Event = raceEvent,
                Enrolments = (result.Data ?? new List<EventEnrolmentDto>())
                    .OrderBy(e => e.ParticipantName)
                    .ToList()
            });
        }

        // status = Paid (shown as Confirmed), Pending or Cancelled
        [HttpPost]
        public async Task<IActionResult> SetStatus(
            int eventId, int enrolmentId, string status)
        {
            var result = await Api.PutAsync(
                $"api/enrolments/{enrolmentId}/status", new { status });

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (result.Success)
            {
                ShowSuccess("The enrolment status was updated.");
            }
            else
            {
                ShowError(result.Error);
            }

            return RedirectToAction(nameof(Index), new { eventId });
        }
    }
}
