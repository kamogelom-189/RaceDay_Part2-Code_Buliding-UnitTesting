using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Models;
using RaceDay.Client.Services;

namespace RaceDay.Client.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            // Signed-in users go straight to their own dashboard.
            if (HttpContext.Session.IsLoggedIn())
            {
                return RedirectToAction("Index", "Dashboard");
            }

            return View();
        }

        [ResponseCache(
            Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            });
        }

        // Re-executed by UseStatusCodePagesWithReExecute (404, 403 ...).
        public IActionResult HandleStatus(int code = 404)
        {
            Response.StatusCode = code;

            if (code == 404)
            {
                return View("NotFoundPage");
            }

            return View("Error", new ErrorViewModel
            {
                RequestId = HttpContext.TraceIdentifier
            });
        }
    }
}
