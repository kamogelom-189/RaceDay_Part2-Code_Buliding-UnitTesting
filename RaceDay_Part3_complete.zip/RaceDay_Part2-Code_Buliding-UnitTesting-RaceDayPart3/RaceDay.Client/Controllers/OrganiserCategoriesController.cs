using Microsoft.AspNetCore.Mvc;
using RaceDay.Client.Filters;
using RaceDay.Client.Models.Api;
using RaceDay.Client.Models.ViewModels;

namespace RaceDay.Client.Controllers
{
    [SessionAuthorize("Organiser")]
    public class OrganiserCategoriesController : BaseController
    {
        // Category management page for ONE event: list + add form.
        [HttpGet]
        public async Task<IActionResult> Index(int eventId)
        {
            var (raceEvent, redirect) = await LoadOwnedEventAsync(eventId);

            if (redirect != null || raceEvent == null)
            {
                return redirect ?? RedirectToAction("Index", "OrganiserEvents");
            }

            return View(await BuildPageAsync(raceEvent, new CategoryFormViewModel
            {
                EventId = eventId
            }));
        }

        [HttpPost]
        public async Task<IActionResult> Create(
            int eventId, CategoryFormViewModel model)
        {
            var (raceEvent, redirect) = await LoadOwnedEventAsync(eventId);

            if (redirect != null || raceEvent == null)
            {
                return redirect ?? RedirectToAction("Index", "OrganiserEvents");
            }

            model.EventId = eventId;

            if (!ModelState.IsValid)
            {
                return View("Index", await BuildPageAsync(raceEvent, model));
            }

            var result = await Api.PostAsync(
                $"api/events/{eventId}/categories", ToPayload(model));

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!result.Success)
            {
                ModelState.AddModelError(string.Empty, result.Error);
                return View("Index", await BuildPageAsync(raceEvent, model));
            }

            ShowSuccess($"The category \"{model.CategoryName.Trim()}\" was added.");

            return RedirectToAction(nameof(Index), new { eventId });
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int eventId, int id)
        {
            var (raceEvent, redirect) = await LoadOwnedEventAsync(eventId);

            if (redirect != null || raceEvent == null)
            {
                return redirect ?? RedirectToAction("Index", "OrganiserEvents");
            }

            var result = await Api.GetAsync<CategoryDto>(
                $"api/events/{eventId}/categories/{id}");

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!result.Success || result.Data == null)
            {
                ShowError(result.Error);
                return RedirectToAction(nameof(Index), new { eventId });
            }

            ViewData["EventTitle"] = raceEvent.Title;

            return View(new CategoryFormViewModel
            {
                CategoryId = result.Data.CategoryId,
                EventId = eventId,
                CategoryName = result.Data.CategoryName,
                DistanceKM = result.Data.DistanceKM,
                EntryFee = result.Data.EntryFee
            });
        }

        [HttpPost]
        public async Task<IActionResult> Edit(
            int eventId, int id, CategoryFormViewModel model)
        {
            var (raceEvent, redirect) = await LoadOwnedEventAsync(eventId);

            if (redirect != null || raceEvent == null)
            {
                return redirect ?? RedirectToAction("Index", "OrganiserEvents");
            }

            model.EventId = eventId;
            model.CategoryId = id;
            ViewData["EventTitle"] = raceEvent.Title;

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var result = await Api.PutAsync(
                $"api/events/{eventId}/categories/{id}", ToPayload(model));

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (!result.Success)
            {
                ModelState.AddModelError(string.Empty, result.Error);
                return View(model);
            }

            ShowSuccess("The category was updated.");

            return RedirectToAction(nameof(Index), new { eventId });
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int eventId, int id)
        {
            var result = await Api.DeleteAsync(
                $"api/events/{eventId}/categories/{id}");

            if (result.IsUnauthorized)
            {
                return SessionExpired();
            }

            if (result.Success)
            {
                ShowSuccess("The category was deleted.");
            }
            else
            {
                ShowError(result.Error);
            }

            return RedirectToAction(nameof(Index), new { eventId });
        }

        private async Task<CategoriesPageViewModel> BuildPageAsync(
            EventDto raceEvent, CategoryFormViewModel form)
        {
            var categories = await Api.GetAsync<List<CategoryDto>>(
                $"api/events/{raceEvent.EventId}/categories");

            if (!categories.Success)
            {
                ShowError(categories.Error);
            }

            return new CategoriesPageViewModel
            {
                Event = raceEvent,
                Categories = categories.Data ?? new List<CategoryDto>(),
                NewCategory = form
            };
        }

        private static object ToPayload(CategoryFormViewModel model) => new
        {
            categoryName = model.CategoryName.Trim(),
            distanceKM = model.DistanceKM,
            entryFee = model.EntryFee
        };
    }
}
