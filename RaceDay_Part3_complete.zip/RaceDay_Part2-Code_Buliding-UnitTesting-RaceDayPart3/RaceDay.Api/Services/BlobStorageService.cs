using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace RaceDay.Api.Services
{
    public class BlobStorageService : IBlobStorageService
    {
        private readonly IConfiguration _configuration;

        public BlobStorageService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // Builds the container client. Read lazily so the app and the
        // unit tests start even when storage is not configured.
        private BlobContainerClient GetContainer()
        {
            string? connectionString =
                _configuration["AzureBlob:ConnectionString"];

            if (string.IsNullOrWhiteSpace(connectionString))
            {
                throw new InvalidOperationException(
                    "Setting 'AzureBlob:ConnectionString' is missing. " +
                    "Set it with: dotnet user-secrets set " +
                    "\"AzureBlob:ConnectionString\" \"<value>\" " +
                    "--project RaceDay.Api");
            }

            string containerName =
                _configuration["AzureBlob:ContainerName"]
                ?? "raceday-images";

            return new BlobContainerClient(connectionString, containerName);
        }

        public async Task<string> UploadAsync(
            Stream content, string fileName, string contentType)
        {
            var container = GetContainer();

            // No PublicAccessType: the container stays PRIVATE.
            // Images are only served through the API.
            await container.CreateIfNotExistsAsync();

            string extension =
                Path.GetExtension(fileName).ToLowerInvariant();
            string blobName = $"{Guid.NewGuid():N}{extension}";

            var blob = container.GetBlobClient(blobName);

            await blob.UploadAsync(content, new BlobUploadOptions
            {
                HttpHeaders = new BlobHttpHeaders
                {
                    ContentType = contentType
                }
            });

            return blobName;
        }

        public async Task<(Stream Content, string ContentType)?> DownloadAsync(
            string blobName)
        {
            var container = GetContainer();
            var blob = container.GetBlobClient(blobName);

            if (!await blob.ExistsAsync())
            {
                return null;
            }

            var download = await blob.DownloadStreamingAsync();

            return (download.Value.Content,
                    download.Value.Details.ContentType ?? "image/jpeg");
        }
    }
}
