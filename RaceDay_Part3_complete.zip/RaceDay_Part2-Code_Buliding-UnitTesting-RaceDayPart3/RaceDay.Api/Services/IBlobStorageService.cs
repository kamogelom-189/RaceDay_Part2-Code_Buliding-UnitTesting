namespace RaceDay.Api.Services
{
    public interface IBlobStorageService
    {
        /// <summary>
        /// Stores the file in Blob Storage and returns the BLOB NAME
        /// (this is what gets saved in SQL Server).
        /// </summary>
        Task<string> UploadAsync(
            Stream content, string fileName, string contentType);

        /// <summary>
        /// Opens a stored blob for reading. Returns null if it does not exist.
        /// </summary>
        Task<(Stream Content, string ContentType)?> DownloadAsync(
            string blobName);
    }
}
