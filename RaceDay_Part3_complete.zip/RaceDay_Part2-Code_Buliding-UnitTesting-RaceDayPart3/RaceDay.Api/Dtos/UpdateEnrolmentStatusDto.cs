using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.DTOs
{
    public class UpdateEnrolmentStatusDto
    {
        // Pending, Paid (shown as "Confirmed" in the web app) or Cancelled.
        [Required]
        [StringLength(20)]
        public string Status { get; set; } = string.Empty;
    }
}
