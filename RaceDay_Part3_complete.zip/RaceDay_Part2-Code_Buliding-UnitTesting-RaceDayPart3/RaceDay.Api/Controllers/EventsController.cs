using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class EventsController : ControllerBase
    {
        private readonly RaceDayContext _context;
        private readonly IBlobStorageService _blobStorage;

        public EventsController(
            RaceDayContext context,
            IBlobStorageService blobStorage)
        {
            _context = context;
            _blobStorage = blobStorage;
        }

        // GET: api/events
        // Both roles can view events.
        [HttpGet]
        public async Task<IActionResult> GetEvents()
        {
            var events = await _context.Events
                .AsNoTracking()
                .OrderBy(e => e.EventDate)
                .Select(e => new
                {
                    e.EventId,
                    e.Title,
                    e.Description,
                    e.EventDate,
                    e.Location,
                    e.DistanceKM,
                    e.EventType,
                    e.OrganiserId,
                    HasBanner = e.BannerBlobName != null
                })
                .ToListAsync();

            return Ok(events);
        }

        // GET: api/events/mine
        // Organiser dashboard: the organiser's own events with
        // category and enrolment counts.
        [HttpGet("mine")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> GetMyEvents()
        {
            var userIdValue = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int organiserId))
            {
                return Unauthorized();
            }

            var events = await _context.Events
                .AsNoTracking()
                .Where(e => e.OrganiserId == organiserId)
                .OrderBy(e => e.EventDate)
                .Select(e => new
                {
                    e.EventId,
                    e.Title,
                    e.Description,
                    e.EventDate,
                    e.Location,
                    e.DistanceKM,
                    e.EventType,
                    e.OrganiserId,
                    HasBanner = e.BannerBlobName != null,
                    CategoryCount = _context.Categories
                        .Count(c => c.EventId == e.EventId),
                    EnrolmentCount = _context.Enrolments
                        .Count(n => n.Category!.EventId == e.EventId
                            && n.PaymentStatus != "Cancelled"),
                    ConfirmedCount = _context.Enrolments
                        .Count(n => n.Category!.EventId == e.EventId
                            && n.PaymentStatus == "Paid"),
                    PendingCount = _context.Enrolments
                        .Count(n => n.Category!.EventId == e.EventId
                            && n.PaymentStatus == "Pending")
                })
                .ToListAsync();

            return Ok(events);
        }

        // GET: api/events/1
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetEventById(int id)
        {
            var raceEvent = await _context.Events
                .AsNoTracking()
                .Where(e => e.EventId == id)
                .Select(e => new
                {
                    e.EventId,
                    e.Title,
                    e.Description,
                    e.EventDate,
                    e.Location,
                    e.DistanceKM,
                    e.EventType,
                    e.OrganiserId,
                    HasBanner = e.BannerBlobName != null
                })
                .FirstOrDefaultAsync();

            if (raceEvent == null)
            {
                return NotFound(new
                {
                    message = "Event not found."
                });
            }

            return Ok(raceEvent);
        }

        // POST: api/events
        // Only Organisers can create events.
        [HttpPost]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> CreateEvent(
            EventRequestDto request)
        {
            var userIdValue = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int organiserId))
            {
                return Unauthorized();
            }

            string eventType =
                request.EventType.Trim().ToLowerInvariant();

            if (!new[] { "run", "walk", "cycle" }
                .Contains(eventType))
            {
                return BadRequest(new
                {
                    message = "Event type must be run, walk or cycle."
                });
            }

            var raceEvent = new RaceEvent
            {
                OrganiserId = organiserId,
                Title = request.Title.Trim(),
                Description = request.Description?.Trim(),
                EventDate = request.EventDate!.Value,
                Location = request.Location.Trim(),
                DistanceKM = request.DistanceKM,
                EventType = eventType
            };

            _context.Events.Add(raceEvent);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetEventById),
                new { id = raceEvent.EventId },
                new
                {
                    raceEvent.EventId,
                    raceEvent.Title,
                    raceEvent.Description,
                    raceEvent.EventDate,
                    raceEvent.Location,
                    raceEvent.DistanceKM,
                    raceEvent.EventType,
                    raceEvent.OrganiserId,
                    HasBanner = false
                });
        }

        // PUT: api/events/1
        // Organisers can update their own events.
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UpdateEvent(
            int id,
            EventRequestDto request)
        {
            var userIdValue = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int organiserId))
            {
                return Unauthorized();
            }

            var raceEvent = await _context.Events
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (raceEvent == null)
            {
                return NotFound(new
                {
                    message = "Event not found."
                });
            }

            if (raceEvent.OrganiserId != organiserId)
            {
                return Forbid();
            }

            string eventType =
                request.EventType.Trim().ToLowerInvariant();

            if (!new[] { "run", "walk", "cycle" }
                .Contains(eventType))
            {
                return BadRequest(new
                {
                    message = "Event type must be run, walk or cycle."
                });
            }

            raceEvent.Title = request.Title.Trim();
            raceEvent.Description = request.Description?.Trim();
            raceEvent.EventDate = request.EventDate!.Value;
            raceEvent.Location = request.Location.Trim();
            raceEvent.DistanceKM = request.DistanceKM;
            raceEvent.EventType = eventType;

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Event updated successfully."
            });
        }

        // POST: api/events/1/banner
        // Organisers upload a banner image for their own event.
        [HttpPost("{id:int}/banner")]
        [Authorize(Roles = "Organiser")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadBanner(
            int id, IFormFile file)
        {
            var userIdValue = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int organiserId))
            {
                return Unauthorized();
            }

            var raceEvent = await _context.Events
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (raceEvent == null)
            {
                return NotFound(new
                {
                    message = "Event not found."
                });
            }

            if (raceEvent.OrganiserId != organiserId)
            {
                return Forbid();
            }

            string? error = ImageValidator.Validate(file);

            if (error != null)
            {
                return BadRequest(new { message = error });
            }

            await using var stream = file.OpenReadStream();

            // The blob NAME is saved in SQL Server.
            raceEvent.BannerBlobName = await _blobStorage.UploadAsync(
                stream, file.FileName, file.ContentType);

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Banner uploaded successfully.",
                raceEvent.BannerBlobName
            });
        }

        // GET: api/events/1/banner
        // Streams the banner image from Blob Storage.
        [HttpGet("{id:int}/banner")]
        public async Task<IActionResult> GetBanner(int id)
        {
            var blobName = await _context.Events
                .Where(e => e.EventId == id)
                .Select(e => e.BannerBlobName)
                .FirstOrDefaultAsync();

            if (string.IsNullOrWhiteSpace(blobName))
            {
                return NotFound();
            }

            var file = await _blobStorage.DownloadAsync(blobName);

            if (file == null)
            {
                return NotFound();
            }

            return File(file.Value.Content, file.Value.ContentType);
        }

        // DELETE: api/events/1
        // Organisers can delete their own events.
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var userIdValue = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int organiserId))
            {
                return Unauthorized();
            }

            var raceEvent = await _context.Events
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (raceEvent == null)
            {
                return NotFound(new
                {
                    message = "Event not found."
                });
            }

            if (raceEvent.OrganiserId != organiserId)
            {
                return Forbid();
            }

            bool hasEnrolments = await _context.Enrolments
                .AnyAsync(e => e.Category != null
                    && e.Category.EventId == id);

            if (hasEnrolments)
            {
                return Conflict(new
                {
                    message = "This event has enrolments and cannot be deleted."
                });
            }

            _context.Events.Remove(raceEvent);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Event deleted successfully."
            });
        }
    }
}
