using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ProfileController : ControllerBase
    {
        private readonly RaceDayContext _context;
        private readonly IBlobStorageService _blobStorage;

        public ProfileController(
            RaceDayContext context,
            IBlobStorageService blobStorage)
        {
            _context = context;
            _blobStorage = blobStorage;
        }

        // GET: api/profile/me
        [HttpGet("me")]
        public async Task<IActionResult> GetMyProfile()
        {
            var userIdValue = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int userId))
            {
                return Unauthorized();
            }

            var user = await _context.Users
                .Include(u => u.Role)
                .FirstOrDefaultAsync(u => u.UserId == userId);

            if (user == null)
            {
                return NotFound(new
                {
                    message = "User profile not found."
                });
            }

            return Ok(new
            {
                user.UserId,
                user.FullName,
                user.Email,
                Role = user.Role?.RoleName,
                HasPicture = user.ProfilePictureBlobName != null,
                user.CreatedAt
            });
        }

        // PUT: api/profile/me
        [HttpPut("me")]
        public async Task<IActionResult> UpdateMyProfile(
            UpdateProfileDto request)
        {
            var userIdValue = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int userId))
            {
                return Unauthorized();
            }

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.UserId == userId);

            if (user == null)
            {
                return NotFound(new
                {
                    message = "User profile not found."
                });
            }

            string email = request.Email.Trim().ToLowerInvariant();

            bool emailExists = await _context.Users
                .AnyAsync(u =>
                    u.UserId != userId &&
                    u.Email.ToLower() == email);

            if (emailExists)
            {
                return Conflict(new
                {
                    message = "This email is already in use."
                });
            }

            user.FullName = request.FullName.Trim();
            user.Email = email;

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Profile updated successfully."
            });
        }

        // POST: api/profile/me/picture
        [HttpPost("me/picture")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadPicture(IFormFile file)
        {
            var userIdValue = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int userId))
            {
                return Unauthorized();
            }

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.UserId == userId);

            if (user == null)
            {
                return NotFound(new
                {
                    message = "User profile not found."
                });
            }

            string? error = ImageValidator.Validate(file);

            if (error != null)
            {
                return BadRequest(new { message = error });
            }

            await using var stream = file.OpenReadStream();

            user.ProfilePictureBlobName = await _blobStorage.UploadAsync(
                stream, file.FileName, file.ContentType);

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Profile picture uploaded successfully.",
                user.ProfilePictureBlobName
            });
        }

        // GET: api/profile/me/picture
        // Streams the signed-in user's profile picture.
        [HttpGet("me/picture")]
        public async Task<IActionResult> GetPicture()
        {
            var userIdValue = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdValue, out int userId))
            {
                return Unauthorized();
            }

            var blobName = await _context.Users
                .Where(u => u.UserId == userId)
                .Select(u => u.ProfilePictureBlobName)
                .FirstOrDefaultAsync();

            if (string.IsNullOrWhiteSpace(blobName))
            {
                return NotFound();
            }

            var file = await _blobStorage.DownloadAsync(blobName);

            if (file == null)
            {
                return NotFound();
            }

            return File(file.Value.Content, file.Value.ContentType);
        }
    }
}
