using System.Collections.Concurrent;
using RaceDay.Api.Services;

namespace RaceDay.Tests
{
    // In-memory stand-in for Azure Blob Storage, so the tests
    // never need an Azure account or the Azurite emulator.
    public class FakeBlobStorageService : IBlobStorageService
    {
        private readonly ConcurrentDictionary<string, (byte[] Data, string ContentType)>
            _blobs = new();

        public async Task<string> UploadAsync(
            Stream content, string fileName, string contentType)
        {
            using var memory = new MemoryStream();
            await content.CopyToAsync(memory);

            string blobName =
                $"{Guid.NewGuid():N}{Path.GetExtension(fileName)}";

            _blobs[blobName] = (memory.ToArray(), contentType);

            return blobName;
        }

        public Task<(Stream Content, string ContentType)?> DownloadAsync(
            string blobName)
        {
            (Stream Content, string ContentType)? result = null;

            if (_blobs.TryGetValue(blobName, out var blob))
            {
                result = (new MemoryStream(blob.Data), blob.ContentType);
            }

            return Task.FromResult(result);
        }
    }
}
