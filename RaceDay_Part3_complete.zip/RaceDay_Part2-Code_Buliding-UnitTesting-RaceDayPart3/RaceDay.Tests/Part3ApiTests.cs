using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDay.Tests
{
    // Tests for the API features added for Part 3:
    // image uploads, enrolment confirmation, dashboard data
    // and the total finishers on "My Results".
    public class Part3ApiTests
    {
        // A valid 1x1 pixel PNG image.
        private static readonly byte[] TinyPng = Convert.FromBase64String(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==");

        private static MultipartFormDataContent ImageForm(
            string contentType = "image/png",
            string fileName = "image.png")
        {
            var form = new MultipartFormDataContent();
            var file = new ByteArrayContent(TinyPng);
            file.Headers.ContentType =
                new MediaTypeHeaderValue(contentType);
            form.Add(file, "file", fileName);
            return form;
        }

        private static async Task<JsonElement> ReadJsonAsync(
            HttpResponseMessage response)
        {
            string json = await response.Content.ReadAsStringAsync();
            using var document = JsonDocument.Parse(json);
            return document.RootElement.Clone();
        }

        [Fact]
        public async Task Organiser_CanUploadBanner_AndDownloadIt()
        {
            using var factory = new RaceDayWebApplicationFactory();
            await factory.InitializeDatabaseAsync();
            using var client = factory.CreateClient();

            var token = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Banner Organiser",
                "banner.organiser@example.com", "Organiser");
            TestApiHelpers.UseToken(client, token);

            int eventId = await TestApiHelpers.CreateEventAsync(client);

            using var form = ImageForm();
            var upload = await client.PostAsync(
                $"/api/events/{eventId}/banner", form);

            Assert.Equal(HttpStatusCode.OK, upload.StatusCode);

            var download = await client.GetAsync(
                $"/api/events/{eventId}/banner");

            Assert.Equal(HttpStatusCode.OK, download.StatusCode);
            Assert.Equal("image/png",
                download.Content.Headers.ContentType?.MediaType);
            Assert.Equal(TinyPng,
                await download.Content.ReadAsByteArrayAsync());

            var eventJson = await ReadJsonAsync(
                await client.GetAsync($"/api/events/{eventId}"));
            Assert.True(eventJson.GetProperty("hasBanner").GetBoolean());
        }

        [Fact]
        public async Task Banner_IsNotFound_WhenEventHasNoBanner()
        {
            using var factory = new RaceDayWebApplicationFactory();
            await factory.InitializeDatabaseAsync();
            using var client = factory.CreateClient();

            var token = await TestApiHelpers.RegisterAndLoginAsync(
                client, "No Banner Organiser",
                "nobanner.organiser@example.com", "Organiser");
            TestApiHelpers.UseToken(client, token);

            int eventId = await TestApiHelpers.CreateEventAsync(client);

            var response = await client.GetAsync(
                $"/api/events/{eventId}/banner");

            Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        }

        [Fact]
        public async Task BannerUpload_RejectsFilesThatAreNotImages()
        {
            using var factory = new RaceDayWebApplicationFactory();
            await factory.InitializeDatabaseAsync();
            using var client = factory.CreateClient();

            var token = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Bad File Organiser",
                "badfile.organiser@example.com", "Organiser");
            TestApiHelpers.UseToken(client, token);

            int eventId = await TestApiHelpers.CreateEventAsync(client);

            using var form = ImageForm("text/plain", "notes.txt");
            var response = await client.PostAsync(
                $"/api/events/{eventId}/banner", form);

            Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        }

        [Fact]
        public async Task Participant_CannotUploadBanner()
        {
            using var factory = new RaceDayWebApplicationFactory();
            await factory.InitializeDatabaseAsync();
            using var client = factory.CreateClient();

            var organiserToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Owner Organiser",
                "owner.organiser@example.com", "Organiser");
            TestApiHelpers.UseToken(client, organiserToken);
            int eventId = await TestApiHelpers.CreateEventAsync(client);

            var participantToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Sneaky Participant",
                "sneaky.participant@example.com", "Participant");
            TestApiHelpers.UseToken(client, participantToken);

            using var form = ImageForm();
            var response = await client.PostAsync(
                $"/api/events/{eventId}/banner", form);

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Fact]
        public async Task User_CanUploadProfilePicture_AndDownloadIt()
        {
            using var factory = new RaceDayWebApplicationFactory();
            await factory.InitializeDatabaseAsync();
            using var client = factory.CreateClient();

            var token = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Picture Participant",
                "picture.participant@example.com", "Participant");
            TestApiHelpers.UseToken(client, token);

            using var form = ImageForm();
            var upload = await client.PostAsync(
                "/api/profile/me/picture", form);

            Assert.Equal(HttpStatusCode.OK, upload.StatusCode);

            var download = await client.GetAsync("/api/profile/me/picture");

            Assert.Equal(HttpStatusCode.OK, download.StatusCode);
            Assert.Equal(TinyPng,
                await download.Content.ReadAsByteArrayAsync());

            var profile = await ReadJsonAsync(
                await client.GetAsync("/api/profile/me"));
            Assert.True(profile.GetProperty("hasPicture").GetBoolean());
        }

        [Fact]
        public async Task Organiser_CanConfirmEnrolment_AndParticipantSeesIt()
        {
            using var factory = new RaceDayWebApplicationFactory();
            await factory.InitializeDatabaseAsync();
            using var client = factory.CreateClient();

            var organiserToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Confirm Organiser",
                "confirm.organiser@example.com", "Organiser");
            TestApiHelpers.UseToken(client, organiserToken);
            int eventId = await TestApiHelpers.CreateEventAsync(client);
            int categoryId =
                await TestApiHelpers.CreateCategoryAsync(client, eventId);

            var participantToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Confirm Participant",
                "confirm.participant@example.com", "Participant");
            TestApiHelpers.UseToken(client, participantToken);
            int enrolmentId = await TestApiHelpers.CreateEnrolmentAsync(
                client, eventId, categoryId);

            TestApiHelpers.UseToken(client, organiserToken);
            var update = await client.PutAsJsonAsync(
                $"/api/enrolments/{enrolmentId}/status",
                new { status = "Paid" });

            Assert.Equal(HttpStatusCode.OK, update.StatusCode);

            TestApiHelpers.UseToken(client, participantToken);
            var mine = await ReadJsonAsync(
                await client.GetAsync("/api/enrolments/my"));

            Assert.Equal("Paid",
                mine[0].GetProperty("paymentStatus").GetString());
        }

        [Fact]
        public async Task EnrolmentStatus_RejectsUnknownStatus()
        {
            using var factory = new RaceDayWebApplicationFactory();
            await factory.InitializeDatabaseAsync();
            using var client = factory.CreateClient();

            var organiserToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Status Organiser",
                "status.organiser@example.com", "Organiser");
            TestApiHelpers.UseToken(client, organiserToken);
            int eventId = await TestApiHelpers.CreateEventAsync(client);
            int categoryId =
                await TestApiHelpers.CreateCategoryAsync(client, eventId);

            var participantToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Status Participant",
                "status.participant@example.com", "Participant");
            TestApiHelpers.UseToken(client, participantToken);
            int enrolmentId = await TestApiHelpers.CreateEnrolmentAsync(
                client, eventId, categoryId);

            TestApiHelpers.UseToken(client, organiserToken);
            var response = await client.PutAsJsonAsync(
                $"/api/enrolments/{enrolmentId}/status",
                new { status = "Banana" });

            Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        }

        [Fact]
        public async Task Participant_CannotChangeEnrolmentStatus()
        {
            using var factory = new RaceDayWebApplicationFactory();
            await factory.InitializeDatabaseAsync();
            using var client = factory.CreateClient();

            var organiserToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Guard Organiser",
                "guard.organiser@example.com", "Organiser");
            TestApiHelpers.UseToken(client, organiserToken);
            int eventId = await TestApiHelpers.CreateEventAsync(client);
            int categoryId =
                await TestApiHelpers.CreateCategoryAsync(client, eventId);

            var participantToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Guard Participant",
                "guard.participant@example.com", "Participant");
            TestApiHelpers.UseToken(client, participantToken);
            int enrolmentId = await TestApiHelpers.CreateEnrolmentAsync(
                client, eventId, categoryId);

            var response = await client.PutAsJsonAsync(
                $"/api/enrolments/{enrolmentId}/status",
                new { status = "Paid" });

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Fact]
        public async Task Organiser_CannotChangeAnotherOrganisersEnrolment()
        {
            using var factory = new RaceDayWebApplicationFactory();
            await factory.InitializeDatabaseAsync();
            using var client = factory.CreateClient();

            var ownerToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "First Organiser",
                "first.organiser@example.com", "Organiser");
            TestApiHelpers.UseToken(client, ownerToken);
            int eventId = await TestApiHelpers.CreateEventAsync(client);
            int categoryId =
                await TestApiHelpers.CreateCategoryAsync(client, eventId);

            var participantToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Other Participant",
                "other.participant@example.com", "Participant");
            TestApiHelpers.UseToken(client, participantToken);
            int enrolmentId = await TestApiHelpers.CreateEnrolmentAsync(
                client, eventId, categoryId);

            var otherToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Second Organiser",
                "second.organiser@example.com", "Organiser");
            TestApiHelpers.UseToken(client, otherToken);

            var response = await client.PutAsJsonAsync(
                $"/api/enrolments/{enrolmentId}/status",
                new { status = "Paid" });

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Fact]
        public async Task OrganiserDashboard_ReturnsEnrolmentCounts()
        {
            using var factory = new RaceDayWebApplicationFactory();
            await factory.InitializeDatabaseAsync();
            using var client = factory.CreateClient();

            var organiserToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Dashboard Organiser",
                "dashboard.organiser@example.com", "Organiser");
            TestApiHelpers.UseToken(client, organiserToken);
            int eventId = await TestApiHelpers.CreateEventAsync(client);
            int categoryId =
                await TestApiHelpers.CreateCategoryAsync(client, eventId);

            var participantToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Dashboard Participant",
                "dashboard.participant@example.com", "Participant");
            TestApiHelpers.UseToken(client, participantToken);
            await TestApiHelpers.CreateEnrolmentAsync(
                client, eventId, categoryId);

            TestApiHelpers.UseToken(client, organiserToken);
            var events = await ReadJsonAsync(
                await client.GetAsync("/api/events/mine"));

            Assert.Equal(1, events.GetArrayLength());
            Assert.Equal(1,
                events[0].GetProperty("categoryCount").GetInt32());
            Assert.Equal(1,
                events[0].GetProperty("enrolmentCount").GetInt32());
            Assert.Equal(0,
                events[0].GetProperty("confirmedCount").GetInt32());
            Assert.Equal(1,
                events[0].GetProperty("pendingCount").GetInt32());
        }

        [Fact]
        public async Task Participant_CannotViewOrganiserDashboard()
        {
            using var factory = new RaceDayWebApplicationFactory();
            await factory.InitializeDatabaseAsync();
            using var client = factory.CreateClient();

            var token = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Dashboard Guard",
                "dashboard.guard@example.com", "Participant");
            TestApiHelpers.UseToken(client, token);

            var response = await client.GetAsync("/api/events/mine");

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Fact]
        public async Task MyResults_IncludesTotalFinishers()
        {
            using var factory = new RaceDayWebApplicationFactory();
            await factory.InitializeDatabaseAsync();
            using var client = factory.CreateClient();

            var organiserToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Finishers Organiser",
                "finishers.organiser@example.com", "Organiser");
            TestApiHelpers.UseToken(client, organiserToken);
            int eventId = await TestApiHelpers.CreateEventAsync(client);
            int categoryId =
                await TestApiHelpers.CreateCategoryAsync(client, eventId);

            var firstToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Runner One",
                "runner.one@example.com", "Participant");
            TestApiHelpers.UseToken(client, firstToken);
            int firstEnrolment = await TestApiHelpers.CreateEnrolmentAsync(
                client, eventId, categoryId);

            var secondToken = await TestApiHelpers.RegisterAndLoginAsync(
                client, "Runner Two",
                "runner.two@example.com", "Participant");
            TestApiHelpers.UseToken(client, secondToken);
            int secondEnrolment = await TestApiHelpers.CreateEnrolmentAsync(
                client, eventId, categoryId);

            TestApiHelpers.UseToken(client, organiserToken);

            var first = await client.PostAsJsonAsync(
                $"/api/events/{eventId}/results",
                new
                {
                    enrolmentId = firstEnrolment,
                    raceNumber = "RD001",
                    finishTime = "00:45:12",
                    position = 1
                });
            Assert.Equal(HttpStatusCode.OK, first.StatusCode);

            var second = await client.PostAsJsonAsync(
                $"/api/events/{eventId}/results",
                new
                {
                    enrolmentId = secondEnrolment,
                    raceNumber = "RD002",
                    finishTime = "00:51:30",
                    position = 2
                });
            Assert.Equal(HttpStatusCode.OK, second.StatusCode);

            TestApiHelpers.UseToken(client, secondToken);
            var mine = await ReadJsonAsync(
                await client.GetAsync("/api/results/my"));

            Assert.Equal(1, mine.GetArrayLength());
            Assert.Equal(2, mine[0].GetProperty("position").GetInt32());
            Assert.Equal(2,
                mine[0].GetProperty("totalFinishers").GetInt32());
        }
    }
}
